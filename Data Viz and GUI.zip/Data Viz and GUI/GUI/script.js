// Database (example stored values)
const database = {
    users: [
      { username: "student1", password: "pass123", role: "Student" },
      { username: "owner1", password: "pass456", role: "Owner" },
      { username: "broker1", password: "pass789", role: "Broker" },
    ],
  };
  
  // Handle Login Form Submission
  document.getElementById("loginForm").addEventListener("submit", (event) => {
    event.preventDefault(); // Prevent default form submission
  
    const role = document.getElementById("role").value;
    const username = document.getElementById("username").value;
    const password = document.getElementById("password").value;
  
    // Check user credentials
    const user = database.users.find(
      (u) => u.username === username && u.password === password && u.role === role
    );
  
    if (user) {
      // Redirect to specific page based on role
      if (role === "Student") {
        window.location.href = "student-dashboard.html"; // Replace with actual file
      } else if (role === "Owner") {
        window.location.href = "owner-dashboard.html"; // Replace with actual file
      } else if (role === "Broker") {
        window.location.href = "broker-dashboard.html"; // Replace with actual file
      }
    } else {
      alert("Invalid login credentials. Please try again.");
    }
  });
  
  document.addEventListener("DOMContentLoaded", () => {
    const images = [
      "bg1.webp",
      "bg2.jpg",
      "bg3.jpg",
      "bg4.jpg",
      "bg5.jpg",
      "bg6.jpg",
    ];
  
    const slideshowContainer = document.getElementById("background-slideshow");
  
    // Create image elements
    images.forEach((src, index) => {
      const img = document.createElement("img");
      img.src = src;
      if (index === 0) img.classList.add("active"); // First image is active
      slideshowContainer.appendChild(img);
    });
  
    const imgElements = document.querySelectorAll("#background-slideshow img");
    let currentIndex = 0;
  
    setInterval(() => {
      imgElements[currentIndex].classList.remove("active");
      currentIndex = (currentIndex + 1) % images.length; // Move to the next image
      imgElements[currentIndex].classList.add("active");
    }, 1500); // Change every 1.5 seconds
  });
  