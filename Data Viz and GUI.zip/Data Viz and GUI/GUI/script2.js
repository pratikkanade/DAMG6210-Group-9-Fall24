document.getElementById('preferences-form').addEventListener('submit', function (event) {
    event.preventDefault();
  
    // Collect form data
    const formData = new FormData(event.target);
  
    const preferences = {
      food: formData.getAll('food'),
      smoking: formData.get('smoking'),
      gender: formData.get('gender') || formData.get('gender-other'),
      beds: formData.getAll('beds'),
      baths: formData.getAll('baths'),
      budget: formData.getAll('budget')
    };
  
    console.log(preferences);
  
    // Replace with your database fetch logic
    alert('Submitting your preferences. Details logged in console.');
  });

  document.getElementById('preferences-form').addEventListener('submit', function (event) {
    event.preventDefault();
  
    try {
      // Collect form data
      const formData = new FormData(event.target);
  
      const preferences = {
        food: formData.getAll('food'),
        smoking: formData.get('smoking'),
        gender: formData.get('gender') || formData.get('gender-other'),
        beds: formData.getAll('beds'),
        baths: formData.getAll('baths'),
        budget: formData.getAll('budget'),
      };
  
      console.log('Collected Preferences:', preferences); // Debugging
  
      // Simulate database results (replace this with actual database query logic)
      const simulatedResults = [
        {
          name: "John Doe",
          food: "Veg",
          smoking: "No",
          gender: "Male",
          beds: 2,
          baths: 1,
          budget: "500-700",
        },
        {
          name: "Jane Smith",
          food: "Non-Veg",
          smoking: "Yes",
          gender: "Female",
          beds: 1,
          baths: 1,
          budget: "700-1000",
        },
        {
          name: "Chris Johnson",
          food: "Veg",
          smoking: "No",
          gender: "Other",
          beds: 3,
          baths: 2,
          budget: "1000 and above",
        },
      ];
  
      console.log('Simulated Results:', simulatedResults); // Debugging
  
      // Filter simulated results based on preferences
      const filteredResults = simulatedResults.filter((item) => {
        return (
          (preferences.food.length === 0 || preferences.food.includes(item.food)) &&
          (!preferences.smoking || preferences.smoking === item.smoking) &&
          (!preferences.gender || preferences.gender === item.gender) &&
          (preferences.beds.length === 0 || preferences.beds.includes(item.beds.toString())) &&
          (preferences.baths.length === 0 || preferences.baths.includes(item.baths.toString())) &&
          (preferences.budget.length === 0 || preferences.budget.includes(item.budget))
        );
      });
  
      console.log('Filtered Results:', filteredResults); // Debugging
  
      // Display results
      const resultsSection = document.getElementById('results-section');
      const resultsContent = document.getElementById('results-content');
      const formSection = document.getElementById('form-section');
  
      // Clear previous results
      resultsContent.innerHTML = '';
  
      if (filteredResults.length === 0) {
        resultsContent.innerHTML = '<p>No matching results found.</p>';
      } else {
        filteredResults.forEach((result) => {
          const resultDiv = document.createElement('div');
          resultDiv.className = 'result-item';
          resultDiv.innerHTML = `
            <p><strong>Name:</strong> ${result.name}</p>
            <p><strong>Food Preference:</strong> ${result.food}</p>
            <p><strong>Smoking/Alcohol:</strong> ${result.smoking}</p>
            <p><strong>Gender:</strong> ${result.gender}</p>
            <p><strong>Beds:</strong> ${result.beds}</p>
            <p><strong>Baths:</strong> ${result.baths}</p>
            <p><strong>Budget:</strong> ${result.budget}</p>
          `;
          resultsContent.appendChild(resultDiv);
        });
      }
  
      // Show results section, hide form section
      formSection.style.display = 'none';
      resultsSection.style.display = 'block';
  
    } catch (error) {
      console.error('Error processing form submission:', error);
    }
  });
  
  function resetForm() {
    document.getElementById('form-section').style.display = 'block';
    document.getElementById('results-section').style.display = 'none';
  }
  